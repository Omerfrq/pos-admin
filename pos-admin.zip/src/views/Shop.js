import React from 'react';
import { ShopForm } from '../components/shop/shopForm';

export const Shop = () => {
  return (
    <div>
      <ShopForm />
    </div>
  );
};
