import React from 'react';
import { Router } from './Router';

const App = () => <Router />;

export default App;
